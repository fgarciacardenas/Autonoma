# ROS simulation for Neobotix mobile robots

This simulation package provides a quick and easy way to try out the autonomous mobile robots from Neobotix. It comes with the most commonly used configuration but is open for any kind of modification.

Please find our documentations in https://docs.neobotix.de/

<img src="https://raw.githubusercontent.com/neobotix/neo_simulation/melodic/neo_git.png">

